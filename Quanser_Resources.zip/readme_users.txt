# README: System Diagnostics and Resource Setup Guide

## Overview 

1. Run the **Select Resources** (step_1_select_resources.bat) script to check for required software and compare it with what is currently installed on your system.
2. Based on the diagnostics, running the **Resource Setup** (step_2_download_resources_*.bat) script to download and set up the necessary resources.
3. Based on your requirements, navigate to Documents\Quanser\1_setup and run configure_matlab.bat/configure_python.bat or both to setup your environment variables

---

## Step 1: Running the Select Resources Script

The first script checks your system for the following:
- Required software installations (e.g., QUARC, Quanser SDK, Quanser Interactive Labs, MATLAB, Python, and Visual Studio).
- Compatibility of software versions.
- Selected resources and products.

### Key Features:

1. **User Input:**
   - The script prompts you to select the type of resources you want to download:
     - Student Content only
     - Research Resources only
     - Both Student and Research Resources
   - You will also select one or more products (e.g., QCar 2, QBot Platform, etc.).
   - Select the software requirements such as Python, MATLAB, or both.

2. **Software Check:**
   - The script verifies the existence of key software directories and environment settings:
     - QUARC
     - Quanser SDK
     - Quanser Interactive Labs
     - MATLAB Simulink (specific versions)
     - Python (version 3.9 or higher)
     - Visual Studio (specific versions)

3. **Truth Table:**
   - At the end of the script, two color-coded tables are generated:
     - **Required vs Installed:** Compares the software required to run your selected resources with what is installed on your system.
     - **Color Codes:**
       - **Green:** Indicates the required software is installed.
       - **Red:** Indicates the required software is missing.

4. **Review the Log**:
   - Upon completion, the script generates a log file named `software_requirements.log`.
   - This file contains all your selections and the diagnostic results.


### How to Run:

1. **Execute the Script**:
   - Double click the script
   ```
   step_1_select_resources.bat

2. Follow the on-screen prompts to:
   - Choose the type of resources to download.
   - Select the products you want to use.
   - Specify software preferences (e.g., Python only, MATLAB only, or both).

3. Review the output log file (`software_requirements.log`) to see:
   - A detailed list of what is currently installed.
   - The comparison tables showing required vs installed software.

---

## Next:
After completing the diagnostics, proceed to run the **Download Resource** script. This script will download and configure any missing components based on the diagnostics results.

## Step 2: Run the Download Resource Batch Script

File: step_2_download_resources_*.bat * -> student/instructor
Ensure that system_diagnostics.bat has been run first and the log file (software_requirements.log) is generated.
- Double-click step_2_download_resources_*.bat to execute it.

1. **The script will**:

- Check if the software_requirements.log exists.
- Download relevant files such as:
  - Common content
  - Autonomous Systems Student files
  - Robotics Student files
  - Research Resources
  - Controls Student files
- Unzip the downloaded files and transfer them to the specified directory.
- Any temporary files, such as .zip files, will be deleted after the setup is complete.

## Step 3: Run the Configure Batch Script

File: configure_*.bat * -> python/matlab
Navigate to Documents\Quanser\1_setup double click the configure files based on your preference to setup matlab, python or both

1. **The script will**:

- Python environment variables will be configured
- MATLAB environment variables will be configured, and the required libraries will be added to the MATLAB path for compatibility.
- The script will install Python dependencies listed in requirements.txt using pip.



