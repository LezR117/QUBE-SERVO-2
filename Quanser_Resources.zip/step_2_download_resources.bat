@echo off
setlocal EnableDelayedExpansion

REM Specify the path to the log file
set "LOG_FILE=%CD%\software_requirements.log"

REM Check if the log file exists
if not exist "%LOG_FILE%" (
    echo.
    echo [91mLog file not found at "%LOG_FILE%".[0m
    echo.
    echo [92mPlease run the step_1_select_resources.bat file first.[0m
    pause
    exit /b 1
)

REM Initialize variables
set "resources="
set "products_content_to_download="

set "download_autonomous_systems_files=0"
set "download_controls_files=0"
set "download_research_files=0"
set "download_robotics_files=0"
set "download_common_content_files=0"


REM Parse the log file
for /f "tokens=1,* delims=:" %%A in ('findstr /c:"Content to Download:" "%LOG_FILE%"') do (
    set "resources=%%B"
)
for /f "tokens=1,* delims=:" %%A in ('findstr /c:"User Product Selection:" "%LOG_FILE%"') do (
    set "products_content_to_download=%%B"
)

REM Display resources and products to download
echo Resources: !resources!
echo Products Content to Download: !products_content_to_download!

REM Download Common content always true
set "download_common_content_files=1"

REM Placeholder for download links
if not "!resources!"=="" (
    if "!resources:Teaching Resources=!" NEQ "!resources!" (

        if not "!products_content_to_download!"=="" (
            if "!products_content_to_download:1_Controls=!" NEQ "!products_content_to_download!" (
                set "download_controls_files=1"
            )
            if "!products_content_to_download:2_Robotics=!" NEQ "!products_content_to_download!" (
                set "download_robotics_files=1"
            )
            if "!products_content_to_download:3_Autonomous_System=!" NEQ "!products_content_to_download!" (           
                set "download_autonomous_systems_files=1"
            )
        )
    )
    if "!resources:Research Resources=!" NEQ "!resources!" (
        set "download_research_files=1"
    )
    goto :download_files
)

:download_files
set "CURR_DIR=%CD%"
:: Define temp directory
set "TEMP_DIR=%USERPROFILE%\Documents\q_temp"
:: Create the directory if it doesn't exist
if not exist "%TARGET_DIR%" mkdir "%TEMP_DIR%"

if exist "%CURR_DIR%\software_requirements.log" (
    echo [93mMoving software_requirements.log to %TEMP_DIR%...[0m
    move "%CURR_DIR%\software_requirements.log" "%TEMP_DIR%"
    echo [92mMove successful![0m
)

:: Change to target directory
cd /d "%TEMP_DIR%"

echo [93mDownloading files to %TEMP_DIR%...[0m

if "!download_common_content_files!"=="1" (
    echo.
    echo [93mDownloading Common Content files...[0m
    ::concept reviews link
    curl -L -o common_content.zip https://quanserinc.box.com/shared/static/rjdtfixwae6er5lcsht0nxyb74wmtvyi.zip
)
if "!download_autonomous_systems_files!"=="1" (
    echo.
    echo [93mDownloading Autonomous Systems Student files...[0m
    ::Autonomous_System_Student link
    curl -L -o autonomous_systems_student.zip https://quanserinc.box.com/shared/static/ul6grcznagb2t4angczm1s22og6vgoh2.zip
)
if "!download_robotics_files!"=="1" (
    echo.
    echo [93mDownloading Robotics Student files...[0m
    ::Robotics_Student link
    curl -L -o robotics_student.zip https://quanserinc.box.com/shared/static/8vp7qx4s9i0rhxrah6q2iyrahe8c5zia.zip
)
if "!download_controls_files!"=="1" (
    echo.
    echo [93mDownloading Controls Student files...[0m
    ::Controls_Student link
    curl -L -o controls_student.zip https://quanserinc.box.com/shared/static/incw7yz5dkpqv7lym4njxhxxzg3byoa6.zip
)
if "!download_research_files!"=="1" (
    echo.
    echo [93mDownloading Research Resources files...[0m
    ::reseach resources link
    curl -L -o research_resources.zip https://quanserinc.box.com/shared/static/pvpyzhojtkdj7w1m6lf6skmdw6v9bod0.zip
)
echo [92mDownload complete![0m
goto :unzip

:unzip
echo.
rem Unzipping the downloaded files
if "!download_common_content_files!"=="1" (
    echo [93mUnzipping Common Content files...[0m
    powershell -Command "Expand-Archive -Path common_content.zip -DestinationPath ./common_content -Force"
)
if "!download_autonomous_systems_files!"=="1" (
    echo [93mUnzipping Autonomous Systems Student files...[0m
    powershell -Command "Expand-Archive -Path autonomous_systems_student.zip -DestinationPath ./autonomous_systems_student -Force"
)
if "!download_robotics_files!"=="1" (
    echo [93mUnzipping Robotics Student files...[0m
    powershell -Command "Expand-Archive -Path robotics_student.zip -DestinationPath ./robotics_student -Force"
)
if "!download_research_files!"=="1" (
    echo [93mUnzipping Research Resources files...[0m
    powershell -Command "Expand-Archive -Path research_resources.zip -DestinationPath ./research_resources -Force"
)
if "!download_controls_files!"=="1" (
    echo [93mUnzipping Controls Student files...[0m
    powershell -Command "Expand-Archive -Path controls_student.zip -DestinationPath ./controls_student -Force"
)
echo [92mFiles unzipped successfully.[0m
goto :move_files_to_Quanser_folder


rem Transfer downloaded files to Quanser directory and create sub-directories based on content
:move_files_to_Quanser_folder
if "!download_common_content_files!"=="1" (
    echo.
    REM Define paths
    set "SRC_FOLDER=common_content\src"
    set "TARGET_DIR=%USERPROFILE%\Documents\Quanser"
    call :move_files_helper !SRC_FOLDER! !TARGET_DIR!
)
if "!download_autonomous_systems_files!"=="1" (
    echo.
    REM Define paths
    set "SRC_FOLDER=autonomous_systems_student\src"
    set "TARGET_DIR=%USERPROFILE%\Documents\Quanser"
    call :move_files_helper !SRC_FOLDER! !TARGET_DIR!
)
if "!download_robotics_files!"=="1" (
    echo.
    REM Define paths
    set "SRC_FOLDER=robotics_student\src"
    set "TARGET_DIR=%USERPROFILE%\Documents\Quanser"
    call :move_files_helper !SRC_FOLDER! !TARGET_DIR!
)
if "!download_research_files!"=="1" (
    echo.
    REM Define paths
    set "SRC_FOLDER=research_resources\src"
    set "TARGET_DIR=%USERPROFILE%\Documents\Quanser"
    call :move_files_helper !SRC_FOLDER! !TARGET_DIR!
)
if "!download_controls_files!"=="1" (
    echo.
    REM Define paths
    set "SRC_FOLDER=controls_student\src"
    set "TARGET_DIR=%USERPROFILE%\Documents\Quanser"
    call :move_files_helper !SRC_FOLDER! !TARGET_DIR!
)

set "DIR=%USERPROFILE%\Documents\Quanser\1_setup"

:: Look for software_requirements.log and move it
if exist "%TEMP_DIR%\software_requirements.log" (
    echo [93mMoving software_requirements.log to %DIR%...[0m
    move "%TEMP_DIR%\software_requirements.log" "%DIR%"
    echo [92mMove successful![0m
)

goto :cleanup

:cleanup
echo.
echo [93mCleaning up...[0m
echo.
REM List of folders to delete
set "FOLDERS=autonomous_systems_student robotics_student controls_student common_content research_resources"
REM List of .zip files to delete
set "ZIP_FILES=autonomous_systems_student.zip robotics_student.zip controls_student.zip common_content.zip research_resources.zip"

REM Check and delete folders
set "ANY_FOLDER_FOUND=0"
for %%F in (%FOLDERS%) do (
    if exist "%%F" (
        rd /s /q "%%F"
        echo Deleted folder: %%F
        set "ANY_FOLDER_FOUND=1"
    )
)

REM Check and delete .zip files
set "ANY_ZIP_FOUND=0"
for %%Z in (%ZIP_FILES%) do (
    if exist "%%Z" (
        del /q "%%Z"
        echo Deleted file: %%Z
        set "ANY_ZIP_FOUND=1"
    )
)

REM Final message based on findings
if "!ANY_FOLDER_FOUND!"=="0" (
    echo No folders were found to delete.
)
if "!ANY_ZIP_FOUND!"=="0" (
    echo No zip files were found to delete.
)

:: Go back to the parent directory before deletion
cd /d "%USERPROFILE%\Documents"

:: Delete q_temp directory
rmdir /s /q "%TEMP_DIR%"

echo [92mCleanup completed.[0m
goto :ending


:move_files_helper
set "SRC_FOLDER=%~1"
set "TARGET_DIR=%~2"

set "TARGET_DIR=%USERPROFILE%\Documents\Quanser"

REM Check if the target directory exists
if not exist "%TARGET_DIR%" (
    echo The target directory does not exist. Creating it...
    mkdir "%TARGET_DIR%"
) else (
    echo The target directory already exists. Tranfering files to target directory.
)

REM Recursively process all files and folders
for /R "%SRC_FOLDER%" %%f in (*) do (
   
    set "full_path=%%f"
    :: Get the relative path of each file
    set "rel_path=!full_path:%CD%\%SRC_FOLDER%=!"
    :: Define target path by appending the relative path to the target directory
    set "dest_path=%TARGET_DIR%!rel_path!"

    :: Create the directory if needed
    if exist "%%f\" (
        mkdir "!dest_path!" >nul 2>&1
    ) else (
        :: Ensure the destination folder exists
        mkdir "!dest_path!\.." >nul 2>&1
        copy "%%f" "!dest_path!" >nul
    )
)
echo [92mMerge operation completed.[0m
goto :eof


:ending
echo.
echo [92mScript completed.[0m
echo [92mDownloaded Resources and moved to Documents/Quanser.[0m
:: Open the start guide pdf
cd /d "%USERPROFILE%\Documents\Quanser"
start getting_started.pdf
endlocal
pause
